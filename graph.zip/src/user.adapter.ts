import { Injectable } from '@nestjs/common';

@Injectable()
export class UserAdapter {
  // public convertDtoToEntity(userDetails: UserInputType): User {
  //   const user = new User();
  //   user.uid = userDetails.uid;
  //   user.name = userDetails.name;
  //   user.photos = new Photo();
  //   user.photos.pid = userDetails.photos.pid;
  //   user.photos.url = userDetails.photos.url;
  //   return user;
  // }
}
