import { ApiModelProperty } from '@nestjs/swagger';
import { ContactType } from './contact.type';
import { Field, ObjectType, ID } from 'type-graphql';

@ObjectType()
export class CompanyType {
  @Field(() => ID)
  company_id?: string;

  @Field()
  @ApiModelProperty()
  company_code: string;

  @Field()
  @ApiModelProperty()
  company_name: string;

  @Field()
  @ApiModelProperty()
  activated_date: string;

  @Field()
  @ApiModelProperty()
  deactivated_date: string;

  @Field()
  @ApiModelProperty()
  status: boolean;

  @Field(type => [ContactType])
  @ApiModelProperty({ type: Object })
  contact: [ContactType];
}
