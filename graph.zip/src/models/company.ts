export class CompanyInput {
  company_id: string;
}
