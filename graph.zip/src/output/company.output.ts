import { ApiModelProperty } from '@nestjs/swagger';
import { ContactOutputType } from './contact.output';
import { Field, ID, ObjectType } from 'type-graphql';

@ObjectType()
export class CompanyOutputType {
  @Field(type => ID)
  @ApiModelProperty()
  company_id?: string;

  @Field()
  @ApiModelProperty()
  company_code: string;

  @Field()
  @ApiModelProperty()
  company_name: string;

  @Field()
  @ApiModelProperty()
  activated_date: string;

  @Field()
  @ApiModelProperty()
  deactivated_date: string;

  @Field()
  @ApiModelProperty()
  status: boolean;

  @Field(type => ContactOutputType)
  @ApiModelProperty({ type: Object })
  contact: ContactOutputType;
}
