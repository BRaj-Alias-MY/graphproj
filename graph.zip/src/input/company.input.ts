import { ApiModelProperty } from '@nestjs/swagger';
import { ContactInputType } from './contact.input';
import { Field, InputType } from 'type-graphql';

@InputType()
export class CompanyInputType {
  @Field()
  @ApiModelProperty()
  company_code: string;

  @Field()
  @ApiModelProperty()
  company_name: string;

  @Field()
  @ApiModelProperty()
  activated_date: string;

  @Field()
  @ApiModelProperty()
  deactivated_date: string;

  @Field()
  @ApiModelProperty()
  status: boolean;

  @Field(type => ContactInputType)
  @ApiModelProperty({ type: Object })
  contact: ContactInputType;
}
