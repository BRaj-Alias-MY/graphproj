import { ApiModelProperty } from '@nestjs/swagger';
import { Field, InputType } from 'type-graphql';

@InputType()
export class ContactInputType {
  @Field()
  @ApiModelProperty()
  door_no: string;

  @Field()
  @ApiModelProperty()
  address_line1: string;

  @Field()
  @ApiModelProperty()
  address_line2: string;

  @Field()
  @ApiModelProperty()
  land_mark: string;

  @Field()
  @ApiModelProperty()
  country: string;

  @Field()
  @ApiModelProperty()
  state: string;

  @Field()
  @ApiModelProperty()
  zipcode: string;

  @Field()
  @ApiModelProperty()
  land_line_no: string;

  @Field()
  @ApiModelProperty()
  mobile_no1: string;

  @Field()
  @ApiModelProperty()
  mobile_no2: string;

  @Field()
  @ApiModelProperty()
  latitude: string;

  @Field()
  @ApiModelProperty()
  longitude: string;
}
