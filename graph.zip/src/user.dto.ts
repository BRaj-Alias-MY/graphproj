import { JoinTable } from 'typeorm';
import { ObjectType, Field, ID } from 'type-graphql';

@ObjectType()
export class UserType {
  @Field(() => ID)
  user_id?: string;
  @Field()
  name: string;
  @Field(type => [PhotoType])
  photos: [PhotoType];
}

@ObjectType()
export class PhotoType {
  @Field(() => ID)
  photo_id?: string;
  @Field()
  url: string;
  @Field(() => ID)
  user_id?: string;
  @Field(type => UserType)
  user: UserType;
}
