import { CompanyInputType } from '../input/company.input';
import { CompanyType } from '../types/company.type';
import { DeepPartial } from 'apollo-env';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { McsCompanies } from '../entities/mcs_companies';
import { Repository } from 'typeorm';

@Injectable()
export class CompanyService {
  constructor(
    @InjectRepository(McsCompanies)
    private readonly companyRepository: Repository<McsCompanies>,
  ) {}

  async getCompany(company_code: string): Promise<McsCompanies[]> {
    return this.companyRepository.find({
      where: { company_code: company_code },
      relations: ['contact'],
    });
  }

  async getCompanies(): Promise<McsCompanies[]> {
    return this.companyRepository.find({ relations: ['contact'] });
  }

  async saveCompany(companyInput: CompanyInputType): Promise<McsCompanies> {
    return this.companyRepository.save(companyInput);
  }
}
