import { CompanyInputType } from 'src/input/company.input';
import { CompanyService } from '../services/CompanyService';
import { Controller, Get, Body, Post } from '@nestjs/common';
import { McsCompanies } from '../entities/mcs_companies';

@Controller('company')
export class CompanyController {
  constructor(private readonly companyService: CompanyService) {}

  @Post('/createCompany')
  async createUser(@Body() input: CompanyInputType): Promise<McsCompanies> {
    console.log(input);
    //  return ;
    const json = JSON.stringify(input);
    const userinput = JSON.parse(json);
    return await this.companyService.saveCompany(userinput);
  }
  @Post('getAll')
  async getAll(): Promise<McsCompanies[]> {
    return await this.companyService.getCompanies();
  }
}
