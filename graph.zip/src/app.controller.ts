import { AppService } from './app.service';
import { User } from './entities/user.entity';
import { UserInputType } from './userInput';
import { Controller, Get, Body, Post } from '@nestjs/common';

import { DeepPartial } from 'apollo-env';

@Controller('user')
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get('/users')
  async getUsers(): Promise<User[]> {
    return await this.appService.getUsers();
  }

  @Post('/create')
  async createUser(@Body() input: UserInputType): Promise<User> {
    console.log(input);
    //  return ;
    const json = JSON.stringify(input);
    const userinput = JSON.parse(json);
    return await this.appService.createUser(userinput);
  }
}
