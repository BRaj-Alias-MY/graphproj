import { AppController } from './app.controller';
import { AppResolver } from './app.resolver';
import { AppService } from './app.service';
import { CompanyController } from './controllers/CompanyController';
import { McsCompanies } from './entities/mcs_companies';
import { McsContactDetails } from './entities/mcs_contact_details';
import { Photo } from './entities/photo.entity';
import { User } from './entities/user.entity';
import { CompanyResolver } from './resolvers/company.resolver';
import { CompanyService } from './services/CompanyService';
import { UserAdapter } from './user.adapter';
import { Module } from '@nestjs/common';
import { GraphQLModule } from '@nestjs/graphql';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [
    GraphQLModule.forRoot({
      autoSchemaFile: 'schema.gql',
      typePaths: ['./**/*.gpl'],
    }),
    TypeOrmModule.forRoot(),
    TypeOrmModule.forFeature([McsCompanies, McsContactDetails, User, Photo]),
  ],
  controllers: [AppController, CompanyController],
  providers: [
    AppService,
    AppResolver,
    UserAdapter,
    CompanyService,
    CompanyResolver,
  ],
})
export class AppModule {}
