import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {McsClusters} from "./mcs_clusters";
import {McsContactDetails} from "./mcs_contact_details";
import {McsDepartments} from "./mcs_departments";


@Entity("mcs_plants",{schema:"public" } )
@Index("fki_fk_plant_cluster",["cluster",])
@Index("fki_fk_plant_contact",["contact",])
export class McsPlants {

    @Column("character varying",{ 
        nullable:false,
        length:100,
        name:"plant_name"
        })
    plant_name:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:50,
        name:"plant_code"
        })
    plant_code:string;
        

    @Column("date",{ 
        nullable:true,
        name:"activated_date"
        })
    activated_date:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"deactivated_date"
        })
    deactivated_date:string | null;
        

    @Column("boolean",{ 
        nullable:true,
        name:"status"
        })
    status:boolean | null;
        

   
    @ManyToOne(type=>McsClusters, mcs_clusters=>mcs_clusters.mcsPlantss,{  })
    @JoinColumn({ name:'cluster_id'})
    cluster:McsClusters | null;


    @Column("uuid",{ 
        nullable:false,
        primary:true,
        default: () => "uuid_generate_v4()",
        name:"plant_id"
        })
    plant_id:string;
        

   
    @ManyToOne(type=>McsContactDetails, mcs_contact_details=>mcs_contact_details.mcsPlantss,{  })
    @JoinColumn({ name:'contact_id'})
    contact:McsContactDetails | null;


   
    @OneToMany(type=>McsDepartments, mcs_departments=>mcs_departments.plant,{ onDelete: 'CASCADE' ,onUpdate: 'CASCADE' })
    mcsDepartmentss:McsDepartments[];
    
}
