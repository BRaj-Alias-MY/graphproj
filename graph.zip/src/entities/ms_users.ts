import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";


@Entity("ms_users",{schema:"public" } )
export class MsUsers {

    @Column("uuid",{ 
        nullable:false,
        primary:true,
        name:"user_id"
        })
    user_id:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:200,
        name:"first_name"
        })
    first_name:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:200,
        name:"last_name"
        })
    last_name:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:20,
        name:"gender"
        })
    gender:string;
        

    @Column("uuid",{ 
        nullable:true,
        name:"role_id"
        })
    role_id:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"activated_date"
        })
    activated_date:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"deactivated_date"
        })
    deactivated_date:string | null;
        

    @Column("boolean",{ 
        nullable:true,
        name:"is_active"
        })
    is_active:boolean | null;
        
}
