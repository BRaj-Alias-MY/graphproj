import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";


@Entity("__EFMigrationsHistory",{schema:"public" } )
export class EfMigrationsHistory {

    @Column("character varying",{ 
        nullable:false,
        primary:true,
        length:150,
        name:"MigrationId"
        })
    MigrationId:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:32,
        name:"ProductVersion"
        })
    ProductVersion:string;
        
}
