import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {McsDepartments} from "./mcs_departments";
import {McsContactDetails} from "./mcs_contact_details";


@Entity("mcs_sections",{schema:"public" } )
@Index("fki_fk_section_contact",["contact",])
@Index("fki_fk_section_department",["department",])
export class McsSections {

    @Column("character varying",{ 
        nullable:false,
        length:100,
        name:"section_name"
        })
    section_name:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:50,
        name:"section_code"
        })
    section_code:string;
        

    @Column("date",{ 
        nullable:true,
        name:"activated_date"
        })
    activated_date:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"deactivated_date"
        })
    deactivated_date:string | null;
        

    @Column("boolean",{ 
        nullable:true,
        name:"status"
        })
    status:boolean | null;
        

   
    @ManyToOne(type=>McsDepartments, mcs_departments=>mcs_departments.mcsSectionss,{ onDelete: 'CASCADE',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'department_id'})
    department:McsDepartments | null;


   
    @ManyToOne(type=>McsContactDetails, mcs_contact_details=>mcs_contact_details.mcsSectionss,{ onDelete: 'CASCADE',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'contact_id'})
    contact:McsContactDetails | null;


    @Column("uuid",{ 
        nullable:false,
        primary:true,
        default: () => "uuid_generate_v4()",
        name:"section_id"
        })
    section_id:string;
        
}
