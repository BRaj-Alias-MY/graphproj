import {
  BaseEntity,
  Column,
  Entity,
  Index,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryColumn,
  PrimaryGeneratedColumn,
  RelationId,
} from 'typeorm';
import { User } from './user.entity';

@Entity('photo', { schema: 'public' })
@Index('fki_fk_photo_user', ['user'])
export class Photo {
  @Column('uuid', {
    nullable: false,
    primary: true,
    default: () => 'uuid_generate_v4()',
    name: 'photo_id',
  })
  photo_id: string;

  @Column('character varying', {
    nullable: true,
    length: 100,
    name: 'url',
  })
  url: string | null;

  @ManyToOne(type => User, user => user.photos, {
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE',
  })
  @JoinColumn({ name: 'user_id' })
  user: User | null;
}
