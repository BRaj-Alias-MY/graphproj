import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {McsClusters} from "./mcs_clusters";
import {McsCompanies} from "./mcs_companies";
import {McsDepartments} from "./mcs_departments";
import {McsPlants} from "./mcs_plants";
import {McsSections} from "./mcs_sections";


@Entity("mcs_contact_details",{schema:"public" } )
export class McsContactDetails {

    @Column("character varying",{ 
        nullable:true,
        length:200,
        name:"door_no"
        })
    door_no:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:200,
        name:"address_line1"
        })
    address_line1:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:200,
        name:"address_line2"
        })
    address_line2:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:200,
        name:"land_mark"
        })
    land_mark:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:200,
        name:"country"
        })
    country:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:200,
        name:"state"
        })
    state:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:200,
        name:"zipcode"
        })
    zipcode:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:20,
        name:"land_line_no"
        })
    land_line_no:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:20,
        name:"mobile_no1"
        })
    mobile_no1:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:20,
        name:"mobile_no2"
        })
    mobile_no2:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:20,
        name:"latitude"
        })
    latitude:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:20,
        name:"longitude"
        })
    longitude:string | null;
        

    @Column("uuid",{ 
        nullable:false,
        primary:true,
        default: () => "uuid_generate_v4()",
        name:"contact_uid"
        })
    contact_uid:string;
        

   
    @OneToOne(type=>McsClusters, mcs_clusters=>mcs_clusters.contact,{ onDelete: 'RESTRICT' , })
    mcsClusters:McsClusters | null;


   
    @OneToOne(type=>McsCompanies, mcs_companies=>mcs_companies.contact,{ onDelete: 'RESTRICT' , })
    mcsCompanies:McsCompanies | null;


   
    @OneToMany(type=>McsDepartments, mcs_departments=>mcs_departments.contact,{ onDelete: 'CASCADE' ,onUpdate: 'CASCADE' })
    mcsDepartmentss:McsDepartments[];
    

   
    @OneToMany(type=>McsPlants, mcs_plants=>mcs_plants.contact)
    mcsPlantss:McsPlants[];
    

   
    @OneToMany(type=>McsSections, mcs_sections=>mcs_sections.contact,{ onDelete: 'CASCADE' ,onUpdate: 'CASCADE' })
    mcsSectionss:McsSections[];
    
}
