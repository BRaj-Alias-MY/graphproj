import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {McsCompanies} from "./mcs_companies";
import {McsContactDetails} from "./mcs_contact_details";
import {McsPlants} from "./mcs_plants";


@Entity("mcs_clusters",{schema:"public" } )
@Index("fki_fk_cluster_company_details",["company",])
@Index("fki_fk_cluster_contact",["contact",],{unique:true})
export class McsClusters {

    @Column("character varying",{ 
        nullable:true,
        length:200,
        name:"cluster_name"
        })
    cluster_name:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:50,
        name:"cluster_code"
        })
    cluster_code:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"activated_date"
        })
    activated_date:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"deactivated_date"
        })
    deactivated_date:string | null;
        

    @Column("boolean",{ 
        nullable:false,
        name:"status"
        })
    status:boolean;
        

   
    @ManyToOne(type=>McsCompanies, mcs_companies=>mcs_companies.mcsClusterss,{  nullable:false,onDelete: 'CASCADE',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'company_id'})
    company:McsCompanies | null;


   
    @OneToOne(type=>McsContactDetails, mcs_contact_details=>mcs_contact_details.mcsClusters,{ onDelete: 'RESTRICT', })
    @JoinColumn({ name:'contact_id'})
    contact:McsContactDetails | null;


    @Column("uuid",{ 
        nullable:false,
        primary:true,
        default: () => "uuid_generate_v4()",
        name:"cluster_id"
        })
    cluster_id:string;
        

   
    @OneToMany(type=>McsPlants, mcs_plants=>mcs_plants.cluster)
    mcsPlantss:McsPlants[];
    
}
