import {
  BaseEntity,
  Column,
  Entity,
  Index,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryColumn,
  PrimaryGeneratedColumn,
  RelationId,
} from 'typeorm';
import { McsClusters } from './mcs_clusters';
import { McsContactDetails } from './mcs_contact_details';

@Entity('mcs_companies', { schema: 'public' })
@Index('fki_fk_company_contact', ['contact'], { unique: true })
export class McsCompanies {
  @Column('character varying', {
    nullable: false,
    length: 200,
    name: 'company_name',
  })
  company_name: string;

  @Column('date', {
    nullable: true,
    name: 'activated_date',
  })
  activated_date: Date | null;

  @Column('date', {
    nullable: false,
    name: 'deactivated_date',
  })
  deactivated_date: Date;

  @Column('boolean', {
    nullable: true,
    name: 'status',
  })
  status: boolean | null;

  @Column('uuid', {
    nullable: false,
    primary: true,
    default: () => 'uuid_generate_v4()',
    name: 'company_id',
  })
  company_id: string;

  @Column('character varying', {
    nullable: true,
    length: 10,
    name: 'company_code',
  })
  company_code: string | null;

  @OneToOne(
    type => McsContactDetails,
    mcs_contact_details => mcs_contact_details.mcsCompanies,
    { cascade: true, onDelete: 'RESTRICT' },
  )
  @JoinColumn({ name: 'contact_id' })
  contact: McsContactDetails | null;

  @OneToMany(type => McsClusters, mcs_clusters => mcs_clusters.company, {
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE',
  })
  mcsClusterss: McsClusters[];
}
