import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {McsPlants} from "./mcs_plants";
import {McsContactDetails} from "./mcs_contact_details";
import {McsSections} from "./mcs_sections";


@Entity("mcs_departments",{schema:"public" } )
@Index("fki_fk_department_contact",["contact",])
@Index("fki_fk_department_plant",["plant",])
export class McsDepartments {

    @Column("uuid",{ 
        nullable:false,
        primary:true,
        default: () => "uuid_generate_v4()",
        name:"department_id"
        })
    department_id:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:100,
        name:"department_name"
        })
    department_name:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:50,
        name:"department_code"
        })
    department_code:string;
        

    @Column("date",{ 
        nullable:true,
        name:"activated_date"
        })
    activated_date:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"deactivated_date"
        })
    deactivated_date:string | null;
        

    @Column("boolean",{ 
        nullable:true,
        name:"status"
        })
    status:boolean | null;
        

   
    @ManyToOne(type=>McsPlants, mcs_plants=>mcs_plants.mcsDepartmentss,{  nullable:false,onDelete: 'CASCADE',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'plant_id'})
    plant:McsPlants | null;


   
    @ManyToOne(type=>McsContactDetails, mcs_contact_details=>mcs_contact_details.mcsDepartmentss,{  nullable:false,onDelete: 'CASCADE',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'contact_id'})
    contact:McsContactDetails | null;


   
    @OneToMany(type=>McsSections, mcs_sections=>mcs_sections.department,{ onDelete: 'CASCADE' ,onUpdate: 'CASCADE' })
    mcsSectionss:McsSections[];
    
}
