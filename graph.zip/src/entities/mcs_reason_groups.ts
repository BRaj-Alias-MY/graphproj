import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";


@Entity("mcs_reason_groups",{schema:"public" } )
export class McsReasonGroups {

    @Column("uuid",{ 
        nullable:false,
        primary:true,
        default: () => "uuid_generate_v4()",
        name:"reason_group_id"
        })
    reason_group_id:string;
        

    @Column("character varying",{ 
        nullable:true,
        length:200,
        name:"reason_group_name"
        })
    reason_group_name:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"activated_date"
        })
    activated_date:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"deactivated_date"
        })
    deactivated_date:string | null;
        

    @Column("boolean",{ 
        nullable:true,
        name:"status"
        })
    status:boolean | null;
        
}
