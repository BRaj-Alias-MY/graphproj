import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";


@Entity("mcs_roles",{schema:"public" } )
export class McsRoles {

    @Column("uuid",{ 
        nullable:false,
        primary:true,
        name:"role_id"
        })
    role_id:string;
        

    @Column("character varying",{ 
        nullable:false,
        name:"role_name"
        })
    role_name:string;
        

    @Column("boolean",{ 
        nullable:true,
        name:"is_active"
        })
    is_active:boolean | null;
        

    @Column("date",{ 
        nullable:true,
        name:"activated_date"
        })
    activated_date:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"deactivated_date"
        })
    deactivated_date:string | null;
        
}
