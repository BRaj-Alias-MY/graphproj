import { ApiModelProperty } from '@nestjs/swagger';
import { Field, InputType } from 'type-graphql';

@InputType()
export class UserInputType {
  @Field()
  @ApiModelProperty()
  name: string;
  @Field(type => [PhotoInputType])
  @ApiModelProperty({ type: Object, isArray: true })
  photos: [PhotoInputType];
}

@InputType()
export class PhotoInputType {
  @Field()
  @ApiModelProperty()
  url: string;
}
