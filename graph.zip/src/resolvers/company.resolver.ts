import { CompanyInputType } from 'src/input/company.input';
import { CompanyOutputType } from '../output/company.output';
import { CompanyRequest } from '../models/company.request';
import { CompanyService } from '../services/CompanyService';
import { CompanyType } from '../types/company.type';
import { McsCompanies } from '../entities/mcs_companies';
import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';

@Resolver('companies')
export class CompanyResolver {
  constructor(private readonly companyService: CompanyService) {}

  @Mutation(() => CompanyType)
  async createCompany(
    @Args('input') input: CompanyInputType,
  ): Promise<McsCompanies> {
    console.log(input);
    //  return ;
    const json = JSON.stringify(input);
    const userinput = JSON.parse(json);
    return await this.companyService.saveCompany(userinput);
  }

  @Query(() => [CompanyOutputType])
  async getAllCompanies() {
    return await this.companyService.getCompanies();
  }

  @Query(() => [CompanyOutputType])
  async getCompany(@Args('company') company: CompanyRequest) {
    const { company_code } = company;
    return await this.companyService.getCompany(company_code);
  }
}
