import {
  BaseEntity,
  Column,
  Entity,
  Index,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryColumn,
  PrimaryGeneratedColumn,
  RelationId,
} from 'typeorm';
import { Photo } from './photo.entity';

@Entity('user', { schema: 'public' })
export class User {
  @Column('character varying', {
    nullable: true,
    name: 'name',
  })
  name: string | null;

  @Column('uuid', {
    nullable: false,
    primary: true,
    default: () => 'uuid_generate_v4()',
    name: 'user_id',
  })
  user_id: string;

  @OneToMany(type => Photo, photo => photo.user, {
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE',
    cascade: true,
  })
  photos: Photo[];
}
