import { User } from './entities/user.entity';
import { UserType } from './user.dto';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class AppService {
  constructor(
    @InjectRepository(User) private readonly userRepository: Repository<User>,
  ) {}
  // async getHello(): Promise<string> {
  //   return await 'Hello World testing new!';
  // }

  async getUsers(): Promise<User[]> {
    return this.userRepository.find({ relations: ['photos'] });
  }
  async createUser(userDto: UserType): Promise<User> {
    // const data = new this.userRepository(userDto);

    return this.userRepository.save(userDto);
  }
}
