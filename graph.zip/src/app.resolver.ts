import { AppService } from './app.service';
import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { User } from './entities/user.entity';
import { UserInputType } from './userInput';
import { UserType } from './user.dto';

@Resolver()
export class AppResolver {
  constructor(private readonly appService: AppService) {}
  // @Query(() => String)
  // async hello() {
  //   return await 'hello ';
  // }
  @Query(() => [UserType])
  async users() {
    return await this.appService.getUsers();
  }
  // @Mutation(() => UserType)
  // async createUser(@Args('input') input: UserInputType) {
  //   const user = JSON.stringify(input);
  //   const userObj: User = JSON.parse(user);
  //   console.log(userObj);
  //   return this.appService.createUser(userObj[0]);
  // }
  @Mutation(() => UserType)
  async createUser(@Args('input') input: UserInputType): Promise<User> {
    console.log(input);
    //  return ;
    const json = JSON.stringify(input);
    const userinput = JSON.parse(json);
    return await this.appService.createUser(userinput);
  }
}
